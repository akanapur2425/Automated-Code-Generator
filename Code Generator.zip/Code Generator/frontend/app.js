document.getElementById('generate').addEventListener('click', () => {
    const requirements = document.getElementById('requirements').value;
    const language = document.getElementById('language').value;

    fetch('http://127.0.0.1:5000/generate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ requirements, language }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        document.getElementById('generated-code').textContent = data.code;
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred: ' + error.message); // Show alert for any errors
    });
});
