from flask import Flask, request, jsonify
from flask_cors import CORS  # Import CORS
from model import generate_code

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    requirements = data.get('requirements')
    language = data.get('language')
    generated_code = generate_code(requirements, language)
    return jsonify({"code": generated_code})

if __name__ == '__main__':
    app.run(debug=True)
